@file:RequiredPlugins("ScriptedQuests","PlayerDataSync","MMOItems","MythicLib")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.quests.Quest
import net.brian.scriptedquests.compability.mythicmobs.KillMobsObjective
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.objectives.*
import net.brian.scriptedquests.quests.TimeLimitQuest
import net.brian.scriptedquests.rewards.*
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit
import org.bukkit.Location


val questID = "daily_activity_01"

class Daily_Activity_01: TimeLimitQuest(questID,"§7[§d活動每日§7] §f艾靈長廊-幻境 [修補裂縫]"){

    val playerIcon = "%squests_icon%";
    val nikaIcon = IconFonts.getNPC(147);
    val niaIcon = IconFonts.getNPC(148);
    val kinIcon = IconFonts.getNPC(188);
    val shanIcon = IconFonts.getNPC(197);

    private val playerName = "§c● §f%player_displayname%§r:";
    private val kinNPC = "§c● §e金§r:";
    private val shanNPC = "§c● §e閃§r:";

    private val mes1 = arrayOf(
        *Utils.getMessage(kinIcon,
            "$kinNPC",
            "§x§8§B§6§7§3§A嗨，看來閃跟你說了",
            "§x§8§B§6§7§3§A是來繼續修補裂縫的吧？",
        ),
        *Utils.getMessage(kinIcon,
            "$kinNPC",
            "§x§8§B§6§7§3§A守護者們也都準備好了",
            "§x§8§B§6§7§3§A收集好四個聖物再去找閃",
            "§x§8§B§6§7§3§A...都在等著你呢！快去吧~",
        ),
    )
    private val mes2 = arrayOf(
        *Utils.getMessage(shanIcon,
            "$shanNPC",
            "§x§8§B§6§7§3§A太棒了，謝謝！",
        ),
        *Utils.getMessage(shanIcon,
            "$shanNPC",
            "§x§8§B§6§7§3§A記得每天都要來幫忙喲",
            "§x§8§B§6§7§3§A明天不見不散",
        ),
    )

    init {
        val world1 = Bukkit.getWorld("2k");
        val obj1 = ListenNPCObjective(this,"obj1",189,*mes1)
            .setInstruction("§7與 §e金 §7對話")
        val obj2 = GiveMultiItemObjective(this,"obj2",197,
            mapOf(
                "QUESTMATERIAL:M018" to 1,
                "QUESTMATERIAL:M019" to 1,
                "QUESTMATERIAL:M020" to 1,
                "QUESTMATERIAL:M021" to 1,
            )).setInstruction{"§7將 §7${it.get("QUESTMATERIAL:M018")}/1 個燃的聖物、§7${it.get("QUESTMATERIAL:M019")}/1 個凜的聖物、§7${it.get("QUESTMATERIAL:M020")}/1 個闇的聖物、§7${it.get("QUESTMATERIAL:M021")}/1 個森的聖物 §7交給 §e閃§r"}
        val obj3 = ListenNPCObjective(this,"obj3",197,*mes2)
            .setInstruction("§7與 §e閃 §7對話")
        pushObjective(obj1,obj2,obj3)

        addRewards(
            MoneyReward(15), //30錢幣
            QuestExpReward(10), //15傭兵聲
            ClassExpReward(80),
            MessageReward("&a➯ &7道具: &b艾靈之箱鑰匙"),
        )
        addEndHook({
            Utils.command("get ${it.name} CONSUMABLE C065")
        })
    }
}


val quest = Daily_Activity_01();
ScriptedQuests.getInstance().questManager.register(quest);

fun onDispose(){
    quest.unregister();
}



