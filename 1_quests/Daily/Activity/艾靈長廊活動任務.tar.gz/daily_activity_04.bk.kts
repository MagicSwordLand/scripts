@file:RequiredPlugins("ScriptedQuests","PlayerDataSync","MMOItems","MythicLib")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.player.PlayerCompleter
import net.brian.scriptedquests.api.quests.Quest
import net.brian.scriptedquests.compability.mythicmobs.KillMobsObjective
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import net.brian.scriptedquests.objectives.*
import net.brian.scriptedquests.quests.TimeLimitQuest
import net.brian.scriptedquests.rewards.*
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit
import org.bukkit.Location


val questID = "daily_activity_04"

class Daily_Activity_04: TimeLimitQuest(questID,"§7[§d活動每日§7] §f四聖物守護 [燃的聖物]"){

    val playerIcon = "%squests_icon%";
    val ranIcon = IconFonts.getNPC(195);

    private val playerName = "§c● §f%player_displayname%§r:";
    private val ranNPC = "§c● §e燃§r:";

    init {
        val world = Bukkit.getWorld("intro");
        val obj1 = ConversationObjective("obj1",195){
            NPCQuestion(*Utils.getMessage(ranIcon,
                "$ranNPC",
                "§x§8§B§6§7§3§A你是來取聖物的傢伙嗎?",
                "§x§8§B§6§7§3§A看看你能不能完成我的挑戰",
            )).addPlayerOptions(
                PlayerOption("§7[§a對話選項§7] §f是嗎? 說說你的挑戰吧")
                    .setResult { player -> it.finish(PlayerCompleter.getInstance(player)) },
                PlayerOption("&7[&a對話選項&7] §f甚麼挑戰…還是先走為妙")
                    .setResult { player -> player.sendMessage(*Utils.getMessage(ranIcon,
                        "$ranNPC",
                        "§x§d§6§d§0§b§8我都還沒說挑戰是甚麼…",
                    ))})
        }
            .setStartInstantly(false);
        obj1.setInstruction("§7與 §e燃 §7對話並選擇選項")
            .setEndProcess {
                it.sendMessage(*Utils.getMessage(ranIcon,
                    "$ranNPC",
                    "§x§8§B§6§7§3§A就去收集16顆艾靈之果吧",
                    "§x§8§B§6§7§3§A讓我看看你的採集技巧吧!",
                ))
                //Utils.command("lp user ${it.name} permission set player.daily_activity_02")
            }
        val obj2 = GiveItemObjective(this,"obj2",195,"COLLECTMATERIAL:M021",16)
            .setInstruction{"§7採收 ${it.amount} / 16 個艾靈之果 並交給 §e燃 §8(放置副手才可繳交)"}
        pushObjective(obj1,obj2)

        addRewards(
            MoneyReward(5), //30錢幣
            QuestExpReward(5), //15傭兵聲
            ClassExpReward(30),
            MessageReward("&a➯ &7道具: &c燃的聖物"),
        )
        addEndHook({
            Utils.command("get ${it.name} QUESTMATERIAL M018")
            //Utils.command("lp user ${it.name} permission unset player.daily_activity_02")
        })
    }
}


val quest = Daily_Activity_04();
ScriptedQuests.getInstance().questManager.register(quest);

fun onDispose(){
    quest.unregister();
}



