@file:RequiredPlugins("ScriptedQuests","PlayerDataSync","MMOItems","MythicLib")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.player.PlayerCompleter
import net.brian.scriptedquests.api.quests.Quest
import net.brian.scriptedquests.compability.mythicmobs.KillMobsObjective
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import net.brian.scriptedquests.objectives.*
import net.brian.scriptedquests.quests.TimeLimitQuest
import net.brian.scriptedquests.rewards.*
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit
import org.bukkit.Location


val questID = "daily_activity_03"

class Daily_Activity_03: TimeLimitQuest(questID,"§7[§d活動每日§7] §f四聖物守護 [森的聖物]"){

    val playerIcon = "%squests_icon%";
    val shenIcon = IconFonts.getNPC(194);

    private val playerName = "§c● §f%player_displayname%§r:";
    private val shenNPC = "§c● §e森§r:";

    init {
        val world = Bukkit.getWorld("intro");
        val obj1 = ConversationObjective("obj1",194){
            NPCQuestion(*Utils.getMessage(shenIcon,
                "$shenNPC",
                "§x§8§B§6§7§3§A你是來取聖物的傢伙嗎?",
                "§x§8§B§6§7§3§A我可不會白白給你",
                "§x§8§B§6§7§3§A看看你能不能承受我的挑戰",)).addPlayerOptions(
                PlayerOption("§7[§a對話選項§7] §f是嗎? 說說你的挑戰吧")
                    .setResult { player -> it.finish(PlayerCompleter.getInstance(player)) },
                PlayerOption("&7[&a對話選項&7] §f氣勢凌人…等著，我會回來的!")
                    .setResult { player -> player.sendMessage(*Utils.getMessage(shenIcon,
                        "$shenNPC",
                        "§x§d§6§d§0§b§8哈哈哈，這就不行啦?",
                    ))})
        }
            .setStartInstantly(false);
        val obj1EndLoc = Location(world,606.45, 61.0, -80.75, 14.53f, -4.95f)
        obj1.setInstruction("§7與 §e森 §7對話並選擇選項")
            .setEndProcess {
                it.sendMessage(*Utils.getMessage(shenIcon,
                    "$shenNPC",
                    "§x§d§6§d§0§b§8用跑酷來證明你的力量吧",
                ))
                it.teleport(obj1EndLoc)
                //Utils.command("lp user ${it.name} permission set player.daily_activity_02")
            }
        val obj2Loc = Location(world,574.54,83.0,-76.41);
        val obj2 = MoveToObjective(this,"obj2", obj2Loc,2.0);
        pushObjective(obj1,obj2)

        addRewards(
            MoneyReward(5), //30錢幣
            QuestExpReward(5), //15傭兵聲
            ClassExpReward(30),
            MessageReward("&a➯ &7道具: &a森的聖物"),
        )
        addEndHook({
            Utils.command("get ${it.name} QUESTMATERIAL M021")
            Utils.command("execute in minecraft:intro run tp ${it.name} 667.20 83.00 -250.55 -216.11 2.73")
            //Utils.command("lp user ${it.name} permission unset player.daily_activity_02")
        })
    }
}


val quest = Daily_Activity_03();
ScriptedQuests.getInstance().questManager.register(quest);

fun onDispose(){
    quest.unregister();
}



