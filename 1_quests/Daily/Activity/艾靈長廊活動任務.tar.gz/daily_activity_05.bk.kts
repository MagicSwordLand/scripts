@file:RequiredPlugins("ScriptedQuests","PlayerDataSync","MMOItems","MythicLib")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.player.PlayerCompleter
import net.brian.scriptedquests.api.quests.Quest
import net.brian.scriptedquests.compability.mythicmobs.KillMobsObjective
import net.brian.scriptedquests.compability.mythicmobs.KillMultiMobsObjective
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import net.brian.scriptedquests.objectives.*
import net.brian.scriptedquests.quests.TimeLimitQuest
import net.brian.scriptedquests.rewards.*
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit
import org.bukkit.Location


val questID = "daily_activity_05"

class Daily_Activity_05: TimeLimitQuest(questID,"§7[§d活動每日§7] §f四聖物守護 [闇的聖物]"){

    val playerIcon = "%squests_icon%";
    val annIcon = IconFonts.getNPC(196);

    private val playerName = "§c● §f%player_displayname%§r:";
    private val annNPC = "§c● §e闇§r:";

    init {
        val world = Bukkit.getWorld("intro");
        val obj1 = ConversationObjective("obj1",196){
            NPCQuestion(*Utils.getMessage(annIcon,
                annNPC,
                "§x§8§B§6§7§3§A你要從我身邊帶走聖物嗎?",
                "§x§8§B§6§7§3§A那就得看你夠不夠格了",
            )).addPlayerOptions(
                PlayerOption("§7[§a對話選項§7] §f你要…做甚麼")
                    .setResult { player -> it.finish(PlayerCompleter.getInstance(player)) },
                PlayerOption("&7[&a對話選項&7] §f快跑啊!")
                    .setResult { player -> player.sendMessage(*Utils.getMessage(annIcon,
                        annNPC,"§x§8§B§6§7§3§A是不是我太嚇人了…?",
                    ))})
        }
            .setStartInstantly(false);
        obj1.setInstruction("§7與 §e闇 §7對話並選擇選項")
            .setEndProcess {
                it.sendMessage(*Utils.getMessage(annIcon,
                    "$annNPC",
                    "§x§8§B§6§7§3§A讓我看到你的英勇吧",
                    "§x§8§B§6§7§3§A擊敗迷宮中我創造的怪物並帶回他們的物件",
                ))
                //Utils.command("lp user ${it.name} permission set player.daily_activity_02")
            }
        val obj2 = KillMultiMobsObjective(this,"obj2", mapOf(
            "活動怪物_艾靈幼龍" to 16))
            .setInstruction{ "§7擊殺艾靈幼龍 ${it.get("活動怪物_艾靈幼龍")}/16"}
        pushObjective(obj1,obj2)

        addRewards(
            MoneyReward(5), //30錢幣
            QuestExpReward(5), //15傭兵聲
            ClassExpReward(30),
            MessageReward("&a➯ &7道具: &7闇的聖物"),
        )
        addEndHook({
            Utils.command("get ${it.name} QUESTMATERIAL M020")
            //Utils.command("lp user ${it.name} permission unset player.daily_activity_02")
        })
    }
}


val quest = Daily_Activity_05();
ScriptedQuests.getInstance().questManager.register(quest);

fun onDispose(){
    quest.unregister();
}



