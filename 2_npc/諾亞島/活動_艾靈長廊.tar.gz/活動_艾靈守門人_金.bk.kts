@file:RequiredPlugins("ScriptedQuests")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.conditions.CanDoQuestCondition
import net.brian.scriptedquests.api.conditions.FinishedQuestsCondition
import net.brian.scriptedquests.api.conditions.IsDoingQuestCondition
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import org.bukkit.entity.Player
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit

val linIcon = IconFonts.getNPC(188);
private val linNPC = "§b● §e金§r:";

val startCh1Q = NPCQuestion(*Utils.getMessage(linIcon,
        "${linNPC}:",
        "§7有什麼事情嗎?",
))
        .addPlayerOptions(
                PlayerOption("§7[§b傳送選項§7] &f我想去艾靈裂縫 &8[冷卻10分鐘]")
                        .addConditions( {it.hasPermission("player.ailingtransport")} )
                        .setResult { player -> command("execute in minecraft:intro run tp ${player.name} 499.72 62.00 -301.11 -89.55 -1.28")
                            command("lp user ${player.name} permission settemp player.ailingtransport false 10m")},
                PlayerOption("§7[§b傳送選項§7] &f我想去艾靈裂縫 &7[&f冷卻中:%luckperms_expiry_time_player.ailingtransport%&7]")
                        .addConditions( {!it.hasPermission("player.ailingtransport")} ),
                PlayerOption("§7[§a對話選項§7] §f沒事")
                        .setResult { player -> player.sendMessage(*Utils.getMessage(linIcon,
                                "§b● §e金§r:",
                                "§7好的",
                        ))},
                PlayerOption("§7[§b傳送選項§7] &f任務跑酷地 &8[森的聖物]")
                        .addConditions(IsDoingQuestCondition("daily_activity_03"))
                        .setResult { player -> command("execute in minecraft:intro run tp ${player.name} 606.45 61.0 -80.75 14.53 -4.95")},
                PlayerOption("§7[§b傳送選項§7] &f任務跑酷地 &8[凜的聖物]")
                        .addConditions(IsDoingQuestCondition("daily_activity_02"))
                        .setResult { player -> command("execute in minecraft:intro run tp ${player.name} 682.58 68.50 -531.44 -400.85 -6.79")},)
fun command(commandString: String){
    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),commandString)
}

ScriptedQuests.getInstance().conversationManager.pushNPCQuestion(188,startCh1Q)