@file:RequiredPlugins("ScriptedQuests")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.conditions.CanDoQuestCondition
import net.brian.scriptedquests.api.conditions.FinishedQuestsCondition
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import org.bukkit.entity.Player
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit

val linIcon = IconFonts.getNPC(196);
private val linNPC = "§b● §e闇§r:";

val copper01 = "daily_activity_05"

val startCh1Q = NPCQuestion(*Utils.getMessage(linIcon,
    "${linNPC}:",
    "§7有什麼事情嗎?",
))
    .addPlayerOptions(
        PlayerOption("§7[§a對話選項§7] §f沒事")
            .setResult { player -> player.sendMessage(*Utils.getMessage(linIcon,
                "§b● §e闇§r:",
                "§7好的",
            ))})
ScriptedQuests.getInstance().questManager.getQuest(copper01).ifPresent {
    startCh1Q.addPlayerOptions(it.getStartOption("§7[§d活動每日§7] §f四聖物守護 [闇的聖物]",false))
}
fun command(commandString: String){
    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),commandString)
}

ScriptedQuests.getInstance().conversationManager.pushNPCQuestion(196,startCh1Q)