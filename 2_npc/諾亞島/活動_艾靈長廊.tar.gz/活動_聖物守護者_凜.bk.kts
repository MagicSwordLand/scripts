@file:RequiredPlugins("ScriptedQuests")

import io.github.clayclaw.lightcargo.kts.environment.bukkit.annotation.RequiredPlugins
import net.brian.scriptedquests.ScriptedQuests
import net.brian.scriptedquests.api.conditions.CanDoQuestCondition
import net.brian.scriptedquests.api.conditions.FinishedQuestsCondition
import net.brian.scriptedquests.api.conditions.IsDoingQuestCondition
import net.brian.scriptedquests.conversation.IconFonts
import net.brian.scriptedquests.conversation.NPCQuestion
import net.brian.scriptedquests.conversation.PlayerOption
import org.bukkit.entity.Player
import net.brian.scriptedquests.utils.Utils
import org.bukkit.Bukkit

val linIcon = IconFonts.getNPC(193);
private val linNPC = "§b● §e凜§r:";

val copper01 = "daily_activity_02"

val startCh1Q = NPCQuestion(*Utils.getMessage(linIcon,
    "${linNPC}:",
    "§7有什麼事情嗎?",
))
    .addPlayerOptions(
        PlayerOption("§7[§b傳送選項§7] &f任務跑酷地")
            .addConditions(IsDoingQuestCondition("daily_activity_02"))
            .setResult { player -> command("execute in minecraft:intro run tp ${player.name} 682.58 68.50 -531.44 -400.85 -6.79")},
        PlayerOption("§7[§a對話選項§7] §f沒事")
            .setResult { player-> player.sendMessage(*Utils.getMessage(linIcon,
                "§b● §e凜§r:",
                "§7好的",
            ))})
ScriptedQuests.getInstance().questManager.getQuest(copper01).ifPresent {
    startCh1Q.addPlayerOptions(it.getStartOption("§7[§d活動每日§7] §f四聖物守護 [凜的聖物]",false))
}
fun command(commandString: String){
    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),commandString)
}

ScriptedQuests.getInstance().conversationManager.pushNPCQuestion(193,startCh1Q)